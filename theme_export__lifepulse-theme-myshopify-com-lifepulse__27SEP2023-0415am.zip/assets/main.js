/**
 * Utils
 */
var KKUtils = (function(){

    // Set Cookie
    const setCookie = function( timer, cookieName, value ) {
        var date = new Date();
        date.setTime( date.getTime() + (timer * 60 * 1000) );

        $.cookie(cookieName, value, {
            expires: date,
            path: '/'
        } );
    };

    /**
     * Get Product Object by its handle
     */
    const getProductObjByHandle = function ( handle ) {
        var url = '/products/' + handle + '.js';

        return JSON.parse(
            $.ajax({
                url: url,
                dataType: 'json',
                global: false,
                async: false,
                success: function (data) {
                    return data;
                }
            }).responseText
        );
    };
  
    return {
        setCookie:setCookie,
        getProductObjByHandle: getProductObjByHandle,
    }
})();
  
/**
 * UIs
 */
var KKUIs = (function(){

    const preloader = function(){
        $(window).on('load', function(){
            $(".spinner-border").fadeOut('slow');
        });
    };

    const goToTop = function(){
        const handler = $(".js-back-to-top");
        if( handler.length ) {

            handler.on("click",function(){
                $('body,html').animate({scrollTop: 0}, 800);
            });

            $(window).scroll(function(){
                if ($(this).scrollTop() > 300) {
                    handler.fadeIn('slow');
                } else {
                    handler.fadeOut('slow');
                }
            });
        }
    };

    const newsletterPopup = function() {

        const popup = $("#js-news-letter-popup");
        if( popup.length ) {
            const delay    = popup.attr("data-delay");
            const timer    = popup.attr("data-timer");
            const closeBtn = popup.find(".js-news-letter-close");

            if( Shopify.designMode === true ) {
                $(window).on('load',function(){
                    setTimeout(function(){
                        $.magnificPopup.open({
                            items: {
                              src: '#js-news-letter-popup'
                            },
                            type: 'inline',
                            preloader: false,
                            focus: '#popup_newsletter_email',
                            modal: false
                          }, 0);
                    }, ( delay*1000 ) );
                });
            } else {
                const cookieName = 'kkNewsletterPopupCookies';
                if ($.cookie( cookieName ) !== "disabled") {
                    $(window).on('load',function(){
                        setTimeout(function(){
                            $.magnificPopup.open({
                                items: {
                                  src: '#js-news-letter-popup'
                                },
                                type: 'inline',
                                preloader: false,
                                focus: '#popup_newsletter_email',
                                modal: false
                            }, 0);
                        }, ( delay*1000 ) );
                    });

                    popup.on('hide.bs.modal', function(e){
                        KKUtils.setCookie( timer, cookieName, 'disabled' );
                    });

                    popup.find('form').submit( KKUtils.setCookie( timer, cookieName, 'disabled' ) );

                    closeBtn.on("click",function(){
                        $.magnificPopup.close();
                    });
                }
            }

        }
    };

    const cookiePolicy = function() {
        const holder = $("#js-cookie-policy");
        if( holder.length ) {
            const done = localStorage.getItem('kkCookiePolicy') || '';
            const btn  = holder.find("#js-cookie-ok");

            if( done === '' ) {
                holder.fadeIn("slow");
            }

            btn.on("click",function(){
                localStorage.setItem('kkCookiePolicy', 'done');
                holder.fadeOut("slow");
            });
        }
    };

    const updateCurrencies = function() {
        var currencySwitcher = jQuery('#js-multi-currencies');
        var shopCurrency     = Shopify.currency.active;
        Currency.convertAll(shopCurrency, currencySwitcher.val() );
    };

    return {
        init: function(){
            preloader();
            goToTop();
            newsletterPopup();
            cookiePolicy();
            updateCurrencies();
        },
        updateCurrencies:updateCurrencies
    };
})();

/**
 * Image Carousel
 */
var KKImageCarousel = (function(){
    const carousel = $(".js-section-image-carousel").find(".js-slick-carousel");

    const kkSlick = function( ele ) {
        var settings = {
            arrows: ele.data('arrows') || false,
            draggable: ele.data('draggable') || false,
            dots: ele.data('dots') || false,
            infinite: ele.data('infinite') || false,
            autoplay: ele.data('autoplay') || false,
            autoplaySpeed: ele.data('autoplayspeed') || 3000,
            cssEase: 'linear',
            speed: ele.data('speed') || 5000,
            slidesToShow: ele.data('slidestoshow') || 1,
            slidesToScroll: ele.data('slidescroll') || 1,
            adaptiveHeight: true,
        };

        var responsive = [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: ( settings.slidesToShow - 1 ) > 1 ? ( settings.slidesToShow - 1 ) : 1,
                    slidesToScroll: ( settings.slidesToScroll - 1 ) > 1 ? ( settings.slidesToScroll - 1 ) : 1,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: ( settings.slidesToShow - 2 ) > 1 ? ( settings.slidesToShow - 2 ) : 1,
                    slidesToScroll: ( settings.slidesToScroll - 2 ) > 1 ? ( settings.slidesToScroll - 2 ) : 1,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: ( settings.slidesToShow - 3 ) > 1 ? ( settings.slidesToShow - 3 ) : 1,
                    slidesToScroll: ( settings.slidesToScroll - 3 ) > 1 ? ( settings.slidesToScroll - 3 ) : 1,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow:1,
                    slidesToScroll:( settings.slidesToScroll - 4 ) > 1 ? ( settings.slidesToScroll - 4 ) : 1,
                }
            }
        ];

        settings.responsive = responsive;

        ele.not('.slick-initialized').slick( settings );
    };

    return {
        init: function() {
            if( carousel.length ) {
                carousel.each(function(){
                    KKImageCarousel.kkSlick( $(this) );
                });
            }
        },
        kkSlick: kkSlick
    };
})();

/**
 *  Testimonial 1 Carousel
 */
var KKTestimonial1Carousel = (function(){
    const carousel = $(".js-section-testimonial-1-carousel").find(".js-slick-carousel");
    const kkSlick  = function( ele ) {

        var slidesToShow = ele.data('slidestoshow');
        var arrSlides    = new Array();

        if( slidesToShow === null || slidesToShow === "" || typeof slidesToShow === "undefined" || !slidesToShow || slidesToShow.length === undefined ) {
            slidesToShow = '3,2,1';
        }
        arrSlides    = slidesToShow.toString().split(",");

        var settings = {
            arrows: ele.data('arrows') || false,
            draggable: ele.data('draggable') || false,
            dots: ele.data('dots') || false,
            infinite: ele.data('infinite') || false,
            autoplay: ele.data('autoplay') || false,
            autoplaySpeed: ele.data('speed') || 3000,
            slidesToShow: parseInt(arrSlides[0]) || 1,
            slidesToScroll: ele.data('slidescroll') || 1,
            adaptiveHeight: true,
        };

        var responsive = [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: parseInt(arrSlides[0]) || 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: parseInt(arrSlides[1]) || 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: parseInt(arrSlides[2]) || 1,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow:1,
                    slidesToScroll:1,
                }
            }
        ];

        settings.responsive = responsive;
      
        ele.not('.slick-initialized').slick( settings );
    };

    return {
        init: function(){
            if( carousel.length ) {
                carousel.each(function(){
                    KKTestimonial1Carousel.kkSlick( $(this) );
                });
            }
        },
        kkSlick: kkSlick
    };
})();

/**
 * Testimonial 2 Carousel
 */
var KKTestimonial2Carousel = (function(){
    const carousel = $(".js-section-testimonial-2-carousel").find(".js-slick-carousel");
    const kkSlick  = function( ele ) {
      
        var slidesToShow = ele.data('slidestoshow');
        var arrSlides    = new Array();

        if( slidesToShow === null || slidesToShow === "" || typeof slidesToShow === "undefined" || !slidesToShow || slidesToShow.length === undefined ) {
            slidesToShow = '3,2,1';
        }
        arrSlides    = slidesToShow.toString().split(",");
      
        var settings = {
            arrows: ele.data('arrows') || false,
            draggable: ele.data('draggable') || false,
            dots: ele.data('dots') || false,
            infinite: ele.data('infinite') || false,
            autoplay: ele.data('autoplay') || false,
            autoplaySpeed: ele.data('speed') || 3000,
            slidesToShow: parseInt(arrSlides[0]) || 1,
            slidesToScroll: ele.data('slidescroll') || 1,
            adaptiveHeight: true,
        };

        var responsive = [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: parseInt(arrSlides[0]) || 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: parseInt(arrSlides[1]) || 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: parseInt(arrSlides[2]) || 1,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow:1,
                    slidesToScroll:1,
                }
            }
        ];

        settings.responsive = responsive;

        ele.not('.slick-initialized').slick( settings );
    };

    return {
        init: function(){
            if( carousel.length ) {
                carousel.each(function(){
                    KKTestimonial2Carousel.kkSlick( $(this) );
                });
            }
        },
        kkSlick: kkSlick
    };
})();

/**
 * Module: Deal Timer
 */
var KKProductDealTimer = (function(){
  const dealTimerElement = $(".js-product-deal-timer");

  const addtoDealTimer = function() {
    $(document).ready(function(){
        function makeTimer() {
            $('.js-product-deal-timer').each(function(e){
                var $This = $(this);

                var endTime   = new Date($This.attr('data-date'));
      			endTime       = (Date.parse(endTime) / 1000);
    
    			var now = new Date();
    			now = (Date.parse(now) / 1000);
    
    			var timeLeft = endTime - now;
    
    			var days = Math.floor(timeLeft / 86400); 
    			var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
    			var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
    			var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));
      
    			if (hours < "10") { hours = "0" + hours; }
    			if (minutes < "10") { minutes = "0" + minutes; }
    			if (seconds < "10") { seconds = "0" + seconds; }
    
    			$This.find(".days").html(days + "<span>" + $This.attr('data-days') + "</span>");
    			$This.find(".hours").html(hours + "<span>" + $This.attr('data-hours') + "</span>");
    			$This.find(".minutes").html(minutes + "<span>" + $This.attr('data-minutes') + "</span>");
    			$This.find(".seconds").html(seconds + "<span>" + $This.attr('data-seconds') + "</span>");
            });
    	}
    	setInterval(function() { makeTimer(); }, 1000);
    });
  };

  return {
      init: function() {
        addtoDealTimer();
      }
  };  
})();

/**
 * Module: WishList
 */
var KKWishList = (function(){
    
    const wishlistPageContainer = $("#js-page-wishlist");
    const wishlistBtnSelector   = ".js-btn-wishlist";
    let   wishlistArray         = localStorage.getItem('kkLocalWishlist') ? JSON.parse( localStorage.getItem('kkLocalWishlist') ) : [];

    const noResult = function() {
      if( wishlistPageContainer.length ) {
          const source   = $("#wishlistNoResult").html();
          const template = Handlebars.compile(source);
          const context  = { title:kktheme.strings.wishlistTitle, body:kktheme.strings.wishlistNoResult };
          const html     = template( context );

          wishlistPageContainer.html( html );
      }
    };

    const hasResult = function( wishlistArray ) {
      if( wishlistPageContainer.length ) {
          var items = [];
          wishlistArray.forEach(function( handle ){
              var productObj       = KKUtils.getProductObjByHandle( handle );
              var compare_at_price = parseFloat( productObj.compare_at_price );
              var price            = parseFloat( productObj.price );
              var is_gr_compare_at_price = false;

              if( compare_at_price > price ) {
                  is_gr_compare_at_price = true;
              }

              items.push({
                  id: productObj.id,
                  handle: handle,
                  title: productObj.title,
                  url: productObj.url,
                  available: productObj.available,
                  price: productObj.price,
                  formatedPrice: Shopify.formatMoney( productObj.price, kktheme.moneyFormat ),
                  compare_at_price: productObj.compare_at_price,
                  formatedComparePrice: Shopify.formatMoney( productObj.compare_at_price, kktheme.moneyFormat ),
                  is_gr_compare_at_price: is_gr_compare_at_price,
                  price_varies: productObj.price_varies,
                  featured_image: productObj.featured_image
              } );
          });

          const source   = $("#wishlistResult").html();
          const template = Handlebars.compile(source);
          const context  = {
              title: kktheme.strings.wishlistTitle,
              items: items
          };
          const html     = template( context );
          wishlistPageContainer.html( html );
          KKUIs.updateCurrencies();
      }
    };

    const addToWishList = function() {
      $('body').on("click", '.js-btn-wishlist', function(){
          var $this   = $(this),
              $handle = $this.attr("data-wishlist-handle");
              $found  = wishlistArray.indexOf( $handle );

          if( !$this.hasClass("wishlist-added") ) {
              $this.addClass("wishlist-added");
              $this.find('span.btn-text').text('Added to Wishlist');
              wishlistArray.push( $handle );
              localStorage.setItem('kkLocalWishlist', JSON.stringify( wishlistArray ) );
          } else {
              $this.removeClass("wishlist-added");
              $this.find('span.btn-text').text('Add to Wishlist');
              wishlistArray.splice( $found, 1 );
              localStorage.setItem('kkLocalWishlist', JSON.stringify( wishlistArray ) );
          }

         // Updating Wishlist Page
          var updateWishlistArr = JSON.parse( localStorage.getItem('kkLocalWishlist') );
          if( updateWishlistArr.length > 0 ) {
              hasResult( updateWishlistArr );
          } else {
              noResult();
          }
      });
    };

    const loadWishlistClass = function() {
      wishlistArray.forEach(function(handle){
          var $item = $('[data-wishlist-handle="'+ handle +'"]');

          if( $item.length ) {
              $item.addClass("wishlist-added");
              $item.find('span.btn-text').text('Added to Wishlist');
          }
      });
    };

    return {
        init: function() {
          if ( typeof ( Storage ) !== 'undefined' ) {
                  if( wishlistArray.length > 0 ) {
                  loadWishlistClass();
                  hasResult( wishlistArray );
              } else {
                  noResult();
              }
          } else {
              alert("Sorry ! No Web Storage Support");
          }

          addToWishList();
        },
        loadWishlistClass:loadWishlistClass
    };
})();

/**
 * Module: Compare
 */
var KKCompare = (function(){
    let compareArray  = localStorage.getItem('kkLocalCompare') ? JSON.parse( localStorage.getItem('kkLocalCompare') ) : [];

    const compareBtnSelector = ".js-btn-compare";
    const countSelector      = '.js-compare-count';
    const countWrap          = '.js-compare-link';

    const addToCompare = function() {
        $('body').on("click", compareBtnSelector, function(){
            var $this   = $(this),
                $handle = $this.attr("data-compare-handle"),
                $found  = compareArray.indexOf( $handle ),
                $action = '';

            if( !$this.hasClass("compare-added") ) {
                $this.addClass("compare-added");
                $this.find('span.btn-text').text('Added to Compare');
                compareArray.push( $handle );
                localStorage.setItem('kkLocalCompare', JSON.stringify( compareArray ) );
                $action = 'add';
                setTimeout(function(){
                    $.magnificPopup.open({
                      items: {
                        src: '#js-compare-modal-popup'
                      },
                      type: 'inline',
                      preloader: false,
                      modal: false
                    }, 0);
                }, 1000);
            } else {
                $this.removeClass("compare-added");
                $this.find('span.btn-text').text('Compare');
                compareArray.splice( $found, 1 );
                localStorage.setItem('kkLocalCompare', JSON.stringify( compareArray ) );
                $action = 'remove';
            }

            /**
             * Update Bottom Compare Icon
             */
            var updateCompateArr = JSON.parse( localStorage.getItem('kkLocalCompare') );
            compareIcon( updateCompateArr );

            /**
             * Update Compare Table
             */
            updateCompateTable( $handle, $action );
        });
    };

    const compareIcon = function( compareArray ){
        var count = Math.ceil( compareArray.length );
        $(countSelector).html( count );
        if( count >= 2 ) {
            $(countSelector).addClass("js-visible");
        } else {
            $(countSelector).removeClass("js-visible");
        }
    };

    const hasResult = function( compareArray ) {
        compareArray.forEach(function( handle ){
            updateCompateTable( handle, 'add' );
        });
    };

    const updateCompateTable = function( $handle, $action ) {
        const $info         = $("ul.js-compare-product-info");
        const $price        = $("ul.js-compare-product-price");
        const $rating       = $("ul.js-compare-product-rating");
        const $sku          = $("ul.js-compare-product-sku");
        const $desc         = $("ul.js-compare-product-desc");
        const $collection   = $("ul.js-compare-product-collection");
        const $availability = $("ul.js-compare-product-availability");
        const $ptype        = $("ul.js-compare-product-ptype");
        const $vendor       = $("ul.js-compare-product-vendor");

        if( $action == 'add' ) {
            var $productObj = KKUtils.getProductObjByHandle( $handle );
            var $variants   = $productObj.variants;

            // Info
                const info_source   = $("#compare-product-info").html();
                const info_template = Handlebars.compile( info_source );
                const info_html     = info_template({
                    handle:$productObj.id,
                    title:$productObj.title,
                    url:$productObj.url,
                    image:$productObj.featured_image
                });
                $info.find('li.no-product-title').remove();
                $info.append( info_html );

            // Pricing
                var compare_at_price       = parseFloat( $productObj.compare_at_price );
                var price                  = parseFloat( $productObj.price );
                var is_gr_compare_at_price = false;

                if( isNaN( compare_at_price ) ) {
                    compare_at_price = 0;
                }

                if( compare_at_price > price ) {
                    is_gr_compare_at_price = true;
                }

                const price_source   = $("#compare-product-price").html();
                const price_template = Handlebars.compile( price_source );
                const price_html     = price_template({
                    handle: $productObj.id,
                    available: $productObj.available,
                    price: $productObj.price,
                    formatedPrice: Shopify.formatMoney( $productObj.price, kktheme.moneyFormat ),
                    compare_at_price: compare_at_price,
                    formatedComparePrice: Shopify.formatMoney( $productObj.compare_at_price, kktheme.moneyFormat ),
                    is_gr_compare_at_price: is_gr_compare_at_price,
                    price_varies: $productObj.price_varies,
                });
                $price.append( price_html );
                KKUIs.updateCurrencies();

            // Rating
            if( $rating.length ) {
                const rating_source   = $("#compare-product-rating").html();
                const rating_template = Handlebars.compile(rating_source);
                const rating_html     = rating_template({ handle:$productObj.id });
                $rating.append( rating_html );
            }

            // SKU
            if( $sku.length ) {
                const sku_source   = $("#compare-product-sku").html();
                const sku_template = Handlebars.compile(sku_source);
                let   $sku_value   = '-';

                $.each( $variants, function( key, value ){
                    let l_sku = value.sku;
                    if( l_sku != '' ) {
                        $sku_value = l_sku;
                        return false;
                    }
                });

                const sku_html     = sku_template({ handle:$productObj.id, sku: $sku_value });
                $sku.append( sku_html );
            }

            // Availability
            if( $availability.length ) {
                const availability_source   = $("#compare-product-availability").html();
                const availability_template = Handlebars.compile(availability_source);
                const availability_html     = availability_template({ handle:$productObj.id, available: $productObj.available });
                $availability.append( availability_html );
            }

            // Product Types
            if( $ptype.length ) {
                var   ptype        = $productObj.type || '-';
                const ptype_source   = $("#compare-product-ptype").html();
                const ptype_template = Handlebars.compile(ptype_source);
                const ptype_html     = ptype_template({ handle:$productObj.id, ptype: ptype });

                $ptype.append( ptype_html );
            }

            // Vendor
            if( $vendor.length ) {
                const vendor_source   = $("#compare-product-vendor").html();
                const vendor_template = Handlebars.compile(vendor_source);
                const vendor_html     = vendor_template({ handle:$productObj.id, vendor:$productObj.vendor });

                $vendor.append( vendor_html );
            }
        } else if( $action == 'remove' ) {
            var $productObj = KKUtils.getProductObjByHandle( $handle );
            var handle_id   = $productObj.id;

            $info.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $price.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $rating.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $sku.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $desc.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $collection.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $availability.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $ptype.find('li[data-compare-handle="'+handle_id+'"]').remove();
            $vendor.find('li[data-compare-handle="'+handle_id+'"]').remove();
        }
    };

    const loadCompareClass = function() {
        compareArray.forEach(function(handle){
            var $item = $('[data-compare-handle="'+ handle +'"]');

            if( $item.length ) {
                $item.addClass("compare-added");
                $item.find('span.btn-text').text('Added to Compare');
            }
        });
    };

    const removeAll = function() {
        $('body').on("click", ".compare-remove-all", function(){
            compareArray.forEach(function(handle){
                var $item = $('[data-compare-handle="'+ handle +'"]');

                if( $item.length ) {
                    $item.removeClass("compare-added");
                    $item.find('span.btn-text').text('Compare');
                }
            });

            compareArray.length = 0;
            localStorage.setItem('kkLocalCompare', JSON.stringify( compareArray ) );
            $("ul.modal-body-data").html("");
            $(countSelector).html("").removeClass("js-visible");
            $("ul.modal-body-data.js-compare-product-info").html('<li class="no-product-title"><h5>No Products Found.</h5></li>');
            setTimeout(function(){
                $.magnificPopup.close();
            }, 1000 );
        });
    };

    const closeModal = function() {
        $("body").on("click", ".js-compare-close-link", function(){
            $.magnificPopup.close();
        });
    };

    const openModal = function(){
        $("body").on("click", countWrap, function(){
            $.magnificPopup.open({
              items: {
                src: '#js-compare-modal-popup'
              },
              type: 'inline',
              preloader: false,
              modal: false
            }, 0);
        });
    };

    return {
        init: function(){
            if ( typeof ( Storage ) !== 'undefined' ) {
                if( compareArray.length > 0 ) {
                    loadCompareClass();
                    compareIcon( compareArray );
                    hasResult( compareArray );
                }

                addToCompare();
                removeAll();

                closeModal();
                openModal();
            } else {
                alert("Sorry ! No Web Storage Support");
            }
        },
        loadCompareClass:loadCompareClass
    };
})();

/**
 * Featured Product Carousel
 */
var KKFeaturedProductCarousel = (function(){
    const carousel = $(".product-featured-section.js-product-featured-slick-slider");
    const kkSlick  = function( ele ) {
        var slidesToShow = ele.data('slidestoshow');
        var arrSlides    = new Array();

        if( slidesToShow === null || slidesToShow === "" || typeof slidesToShow === "undefined" || !slidesToShow || slidesToShow.length === undefined ) {
            slidesToShow = '3,2,1';
        }
        arrSlides    = slidesToShow.toString().split(",");

        var effect_val = false;
        var effect = ele.data('effect');
        if( effect == 'fade' ) {
            effect_val = true;
        } else {
            effect_val = false;
        }
      
        var settings = {
            arrows: ele.data('arrows') || false,
            draggable: ele.data('draggable') || false,
            dots: ele.data('dots') || false,
            infinite: ele.data('infinite') || false,
            autoplay: ele.data('autoplay') || false,
            autoplaySpeed: ele.data('speed') || 3000,
            slidesToShow: parseInt(arrSlides[0]) || 1,
            slidesToScroll: ele.data('slidescroll') || 1,
            fade: effect_val,
            adaptiveHeight: true
        };
      
        var responsive = [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: parseInt(arrSlides[0]) || 3,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: parseInt(arrSlides[1]) || 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: parseInt(arrSlides[2]) || 1,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow:1,
                    slidesToScroll:1,
                }
            }
        ];

        settings.responsive = responsive;

        ele.not('.slick-initialized').slick( settings );
    };

    return {
        init: function(){
            if( carousel.length ) {
                carousel.each(function(){
                    KKFeaturedProductCarousel.kkSlick( $(this) );

                    $(this).one('inview', function (event, visible) {
                        if(visible === true) {
                          $(this).slick('refresh');
                        }
                    });                  
                });
            }

            $('.nav-tabs .nav-item .nav-link').on('click', function(e){
                var $target = $(this).attr('data-bs-target');
                $($target).find('.js-product-featured-slick-slider').slick('refresh');
                e.preventDefault();
            });       
        },
        kkSlick: kkSlick
    };
})();

/**
 * Section: Custom Elements
 */
var KKCustomElements = (function(){
    const section = $(".js-section-custom-elements");

    const KKAnimateNumber = function( section ) {
        const number = section.find(".js-animate-number");

        number.each(function(){
            var field  = $(this).find(".number"),
                number = field.attr("data-number");
                prefix = field.attr("data-prefix");

            if( typeof prefix === "undefined" ) {
                var numberStep = $.animateNumber.numberStepFactories.separator(',', 3 );
            } else {
                var numberStep = $.animateNumber.numberStepFactories.separator(',', 3, prefix );
            }

            $(this).one('inview', function (event, visible) {
                if(visible === true) {
                    field.animateNumber({
                        number:number,
                        numberStep: numberStep
                    }, 1000 );
                }
            });
        });
    };

    return {
        init: function(){
            if( section.length ){
                section.each(function(){
                    KKCustomElements.KKAnimateNumber( $(this) );
                });
            }
        },
        KKAnimateNumber: KKAnimateNumber
    };
})();

/**
 * Template: Collection
 */
var KKCollectionPage = (function(){
    const KKInitView = function(){
        $(document).ready(function(){
            var view = $.cookie( 'collectionColView' );
            if( view != null ) {
                var css_class = "grid-view";
              
                if( view == 'grid' ) {
                    css_class = "grid-view";
                } else if( view == 'list' ) {
                    css_class = "list-view";
                }
    
                $(".product-grid-container #product-grid").find("li.grid__item").removeClass().addClass( css_class ).addClass('grid__item');
                $('.products-view-btns').find(".active").removeClass("active");
                $(".js-collection-view-type.btn-view-" + view).addClass('active');
            } else {
                $(".js-collection-view-type.btn-view-grid").addClass('active');
            }
        });
    };

    const KKGridView = function() {
        $("#FacetSortForm").on("click", '.js-collection-view-type', function(){
            var item   = $(this),
                parent = item.parent(".products-view-btns"),
                view    = item.attr("data-view");

            parent.find(".active").removeClass("active");
            item.addClass("active");

            var css_class = "grid-view";

            if( view == 'grid' ) {
                css_class = "grid-view";
            } else if( view == 'list' ) {
                css_class = "list-view";
            }

            $(".product-grid-container #product-grid").find("li.grid__item").removeClass().addClass( css_class ).addClass('grid__item');

            $.cookie("collectionColView", view, {
              expires: 1,
              path: "/"
            });
        });
    };

    return {
        init: function() {
            KKCollectionPage.KKInitView();
            KKCollectionPage.KKGridView();
        },
        KKInitView:KKInitView,
        KKGridView:KKGridView
    };
})();  

/**
 * Module: Product Ask Question
 */
var KKProductAskQuestion = (function(){  
  const addProductAskQuestion = function() {
    document.addEventListener('DOMContentLoaded', function() {      
        $(document).ready(function(){
            $(".quick-add-modal").on('click', '.js-btn-askquestion-model', function(e){              
                var $This = $(this);
                var $content = $This.next('.modal-popup-main' ).attr('id');
              
                $.magnificPopup.open({
                  items: {
                    src: '#' + $content
                  },
                  type: 'inline',
                  fixedContentPos: false,
                  fixedBgPos: true,
                  overflowY: 'auto',
                  closeBtnInside: true,                  
                  preloader: false,
                  midClick: true,
                  removalDelay: 300,
                  focus: '#contact_name',
                  modal: false,
                  mainClass: 'my-mfp-zoom-in'
                }, 0);
                e.preventDefault(); 
            });
        });
    });
  };

  return {
      init: function() {
        addProductAskQuestion();
      }
  };  
})();

/**
 * Init
 */
KKUIs.init();
KKImageCarousel.init();
KKTestimonial1Carousel.init();
KKTestimonial2Carousel.init();
KKProductDealTimer.init();
document.addEventListener('DOMContentLoaded', function() {
  KKWishList.init();
});
KKCompare.init();
KKFeaturedProductCarousel.init();
KKCustomElements.init();
KKCollectionPage.init();
KKProductAskQuestion.init();

$(document).on('shopify:section:load', function(e){
    $el = $( e.target );

    /**
     * Section: Image carousel
     */
    if( $el.hasClass("js-section-image-carousel") ) {
        const carousel = $el.find(".js-slick-carousel");
        if( carousel.length ) {
            carousel.each(function(){
                KKImageCarousel.kkSlick( $(this) );
            });
        }
    }
  
    /**
     * Section: Testimonial 1
     */
    if( $el.hasClass("js-section-testimonial-1-carousel") ) {
        const carousel = $el.find(".js-slick-carousel");
        if( carousel.length ) {
            carousel.each(function(){
                KKTestimonial1Carousel.kkSlick( $(this) );
            });
        }
    }

    /**
     * Section: Testimonial 2
     */
    if( $el.hasClass("js-section-testimonial-2-carousel") ) {
        const carousel = $el.find(".js-slick-carousel");
        if( carousel.length ) {
            carousel.each(function(){
                KKTestimonial2Carousel.kkSlick( $(this) );
            });
        }
    }
});

/**
 * Banner button smooth scroll...
 */
$('a[href*="#"].btn-banner-appointment')
  // Remove links that don't actually link to anything
  .not('[href="#"]')
  .not('[href="#0"]')
  .click(function(event) {
    // On-page links
    if (
      location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
      && 
      location.hostname == this.hostname
    ) {
      // Figure out element to scroll to
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        event.preventDefault();
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          };
        });
      }
    }
  });